Thank you very much for downloading the Mandelbrot
World Version 1.0! And welcome to Xebec!

The Mandelbrot World Version 1.0 is a tiny Java program 
which helps you explore the beauty of fractals. In order 
to run it, you need the Java 2 platform, which are 
downloadable from Sun Microsystem's Java web site

http://java.sun.com

Once you have the Java 2 platform, open a DOS console
if you use a Windows 9x operation system, or a X window 
if you use a UNIX operation system, and run in the
command line 

c:\mydirectory\java Mandel

assuming that you uncompress the class files onto a
directory called 'mydirectory'.

You can redistribute any software by Xebec Software
freely without the need to ask for a permission. But
I would greatly appreciate your referring to the authorship
of Xebec Software when doing so. 

Xebec Software is a developer of scientific freeware. 
Xebec can be reached at

http://meltingpot.frtunecity.com/trinity/660
http://qianxie.topcool.net (mirror)

(C)1999 Xebec Software <qianxie@hotmail.com>




